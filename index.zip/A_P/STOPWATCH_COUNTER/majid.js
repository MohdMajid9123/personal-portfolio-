
let hr = 0;
let min = 0;
let sec = 0;
let msec = 0;

let majid = false;

//START FUNCTION
function start() {
  majid = true;
  timercount();
}


//STOP FUNTION
function stop() {
  majid = false;
}


//RESET FUNCTION
function rest() {
  majid = false;
  hr = 0;
  min = 0;
  sec = 0;
  msec = 0;
  document.querySelector("#hour").innerHTML = "00";
  document.querySelector("#minut").innerHTML = "00";
  document.querySelector("#second").innerHTML = "00";
  document.querySelector("#msecond").innerHTML = "00";
}


//STOPWATCH FUNCTION
function timercount() {
  if (majid == true) {
    msec = msec + 1;
    if (msec == 100) {
      sec = sec + 1;
      msec = 0;
    }
    if (sec == 60) {
      min = min + 1;
      sec = 0;
    }
    if (min == 60) {
      hr = hr + 1;
      min = 0;
    }



 // jb start btn ko aap click karte hai to sara zero number  single zero (0) hogata hai usse ko double karne ke liye hai
    let hrStr = hr;
    let minStr = min;
    let secStr = sec;
    let msecStr = msec;

    if (hr < 10) {
      hrStr = "0" + hrStr;
    }
    if (min < 10) {
      minStr = "0" + minStr;
    }
    if (sec < 10) {
      secStr = "0" + secStr;
    }
    if (msec < 10) {
      msecStr = "0" + msecStr;
    }

    document.querySelector("#hour").innerHTML = hrStr;
    document.querySelector("#minut").innerHTML = minStr;
    document.querySelector("#second").innerHTML = secStr;
    document.querySelector("#msecond").innerHTML = msecStr;

    setTimeout("timercount()", 10);
  }
}
