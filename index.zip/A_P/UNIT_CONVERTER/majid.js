let foot = document.querySelector("#foot");
let inche = document.querySelector("#inche");

foot.addEventListener("input", function () {
  let majid = this.value;
  let sajid = majid * 12;
  inche.value = sajid;
});

inche.addEventListener("input", function () {
  let saif = this.value;
  let khan = saif / 12;
  if (!Number.isInteger(khan)) {
    khan = khan.toFixed(2);
  }
  foot.value = khan;
});
