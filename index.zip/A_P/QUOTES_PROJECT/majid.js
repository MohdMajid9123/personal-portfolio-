const newQEl = document.querySelector("#newQ");
const quoteEl = document.querySelector("#quotes");
const authorEl = document.querySelector("#author");

newQEl.addEventListener("click", () => {
  fetch("https://type.fit/api/quotes")
    .then((response) => {
      return response.json();
    })
    .then((data) => {
      console.log(data);
      let rNumber = Math.round(Math.random() * 500);
      console.log(rNumber);

      quoteEl.innerText = `${data[rNumber].text}`;

      if (data[rNumber].author == null) {
        authorEl.innerText = "By unknown";
      } else {
        authorEl.innerText = `By ${data[rNumber].author}`;
      }
    })
    .catch((ero) => console.log("we get an error"));
});
