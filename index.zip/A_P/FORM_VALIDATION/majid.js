let userName = document.querySelector("#name");
console.log(userName);
let userPass = document.querySelector("#pass");
let fleg = 1;

let submitForm = (e) => {
  if (userName.value == "") {
    document.querySelector("#userE").innerHTML = "user name is empty";
    console.log(userName.value);
    fleg = 0;
  } else if (userName.value.length < 3) {
    document.querySelector("#userE").innerHTML = "must be 3 letter";
    fleg = 0;
  } else {
    document.querySelector("#userE").innerHTML = "";
    fleg = 1;
  }
  if (userPass.value == "") {
    document.querySelector("#passE").innerHTML = " password is empty";
    fleg = 0;
  } else if (userPass.value.length < 8) {
    document.querySelector("#passE").innerHTML = "must be 8 letter";
    fleg = 0;
  } else {
    document.querySelector("#passE").innerHTML = "";
    fleg = 1;
  }
  if (fleg) {
    return true;
  } else {
    return false;
  }
};
