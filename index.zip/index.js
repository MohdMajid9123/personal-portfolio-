const workSection = document.querySelector(".counter_container");

const workObserver = new IntersectionObserver(
  (entries, observer) => {
    const [entry] = entries;

    // console.log(entry);
    if (entry.isIntersecting == false) return;

    // animate number

    const counterNumber = document.querySelectorAll(".counter_numbers");

    const speed = 200;

    counterNumber.forEach((e) => {
      const updateNumber = () => {
        const targetNumber = parseInt(e.dataset.number);
        // console.log(targetNumber);
        const initialNum = parseInt(e.innerText);
        // console.log(initialNum);
        const increNum = Math.round(targetNumber / speed);
        // console.log(increNum);
        if (initialNum < targetNumber) {
          e.innerText = `${initialNum + increNum}+ `;
          setTimeout(updateNumber, 10);
        }
      };
      updateNumber();
    });
    observer.unobserve(workSection);
  },
  {
    root: null,
    threshold: 0,
  }
);
workObserver.observe(workSection);

// icon_button code

const headerEl = document.querySelector("header");
const icon_buttonEl = document.querySelector(".icon_button");

icon_buttonEl.addEventListener("click", () => {
  headerEl.classList.toggle("active");
});

const ancEl = document.querySelectorAll("nav a");

ancEl.forEach((e) => {
  e.addEventListener("click", () => {
    headerEl.classList.remove("active");
  });
});

// sticky navbar section

const homeEl = document.querySelector("#home");

const majid = new IntersectionObserver(
  (saif) => {
    const ent = saif[0];
    // console.log(ent);
    !ent.isIntersecting
      ? document.body.classList.add("sticky")
      : document.body.classList.remove("sticky");
  },
  { root: null, threshold: 0 }
);
majid.observe(homeEl);

// scroll button code

const scrollEl = document.querySelector("#scroll");

scrollEl.addEventListener("click", () => {
  window.scrollTo({
    top: 0,
    left: 100,
    behavior: "smooth",
  });
});
